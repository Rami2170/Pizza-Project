module com.example.pizzaproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.pizzaproject to javafx.fxml;
    exports com.example.pizzaproject;
}